package com.example.agency.cars.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;
import java.util.Date;

@Value
@Builder
public class QuotationResponse {

    private Integer idQuotation;
    private Integer idCustomer;
    @JsonProperty("Customer name")
    private String customerName;
    @JsonProperty("Offered price")
    private Double offeredPrice;
    private String validity;
    private Date date;
}
