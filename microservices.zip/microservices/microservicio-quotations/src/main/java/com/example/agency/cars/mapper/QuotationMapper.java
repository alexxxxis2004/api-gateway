package com.example.agency.cars.mapper;

import com.example.agency.cars.dto.QuotationRequest;
import com.example.agency.cars.dto.QuotationResponse;
import com.example.agency.cars.model.Customer;
import com.example.agency.cars.model.Quotation;

public class QuotationMapper {

    public static QuotationResponse toResponse(Quotation quotation) {
        if (quotation == null) return null;

        return QuotationResponse.builder()
                .idQuotation(quotation.getIdQuotation())
                .idCustomer(quotation.getCustomer() != null ? quotation.getCustomer().getIdCustomer() : null)
                .customerName(quotation.getCustomer() != null ? quotation.getCustomer().getName() : null)
                .date(quotation.getDate())
                .offeredPrice(quotation.getOfferedPrice())
                .validity(quotation.getValidity())
                .build();
    }

    public static Quotation toEntity(QuotationRequest dto, Customer customer) {
        if (dto == null) return null;

        return Quotation.builder()
                .customer(customer)
                .date(dto.getDate())
                .offeredPrice(dto.getOfferedPrice())
                .validity(dto.getValidity())
                .build();
    }

    public static void copyToEntity(QuotationRequest dto, Quotation entity, Customer customer) {
        if (dto == null || entity == null) return;

        if (customer != null) {
            entity.setCustomer(customer);
        }
        entity.setDate(dto.getDate());
        entity.setOfferedPrice(dto.getOfferedPrice());
        entity.setValidity(dto.getValidity());
    }
}
