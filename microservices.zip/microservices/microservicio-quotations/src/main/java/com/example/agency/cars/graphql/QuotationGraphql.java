package com.example.agency.cars.graphql;

import com.example.agency.cars.dto.QuotationRequest;
import com.example.agency.cars.dto.QuotationResponse;
import com.example.agency.cars.service.QuotationService;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class QuotationGraphql {

    private final QuotationService service;

    public QuotationGraphql(QuotationService service) {
        this.service = service;
    }

    @QueryMapping
    public List<QuotationResponse> getQuotationsByCustomer(@Argument Integer idCustomer) {
        return service.getQuotationsByCustomer(idCustomer);
    }
    
    @MutationMapping
    public QuotationResponse createQuotation(@Argument QuotationRequest data) {
        return service.createQuotation(data);
    }

    @MutationMapping
    public QuotationResponse updateQuotation(@Argument Integer idQuotation, @Argument QuotationRequest data) {
        return service.updateQuotation(idQuotation, data);
    }

    @MutationMapping
    public Boolean deleteQuotation(@Argument Integer idQuotation) {
        service.deleteQuotation(idQuotation);
        return true;
    }
}
