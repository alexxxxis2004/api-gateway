package com.example.agency.cars.repository;

import com.example.agency.cars.model.Customer;
import com.example.agency.cars.model.Quotation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface QuotationRepository extends JpaRepository<Quotation, Integer> {
      List<Quotation> findByCustomer(Customer customer);
}
