package com.example.agency.cars.dto;

import jakarta.validation.constraints.*;
import lombok.Data;
import java.util.Date;

@Data
public class QuotationRequest {

    @NotNull(message = "The customer ID is mandatory")
    private Integer idCustomer;

    @NotNull(message = "The date is mandatory")
    @PastOrPresent(message = "The date cannot be in the future")
    private Date date;

    @NotNull(message = "The offered price is mandatory")
    @DecimalMin(value = "0.0", inclusive = true, message = "The offered price cannot be negative")
    private Double offeredPrice;

    @NotBlank(message = "The validity is mandatory")
    @Size(max = 50, message = "The validity cannot exceed 50 characters")
    private String validity;
}
