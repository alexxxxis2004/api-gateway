package com.example.agency.cars.service;

import com.example.agency.cars.dto.QuotationRequest;
import com.example.agency.cars.dto.QuotationResponse;
import java.util.List;

public interface QuotationService {

    QuotationResponse createQuotation(QuotationRequest data);

    List<QuotationResponse> getQuotationsByCustomer(Integer idCustomer);

    QuotationResponse updateQuotation(Integer idQuotation, QuotationRequest data);

    void deleteQuotation(Integer idQuotation);
}
