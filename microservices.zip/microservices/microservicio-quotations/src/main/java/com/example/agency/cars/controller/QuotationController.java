package com.example.agency.cars.controller;

import com.example.agency.cars.dto.QuotationRequest;
import com.example.agency.cars.dto.QuotationResponse;
import com.example.agency.cars.service.QuotationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/quotations")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
@Tag(name = "Quotations", description = "Provides methods for managing quotations")
public class QuotationController {

    private final QuotationService quotationService;

    public QuotationController(QuotationService quotationService) {
        this.quotationService = quotationService;
    }

    @Operation(
            summary = "Create a new quotation for a customer",
            responses = {
                    @ApiResponse(
                            responseCode = "201",
                            description = "Quotation created successfully",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = QuotationResponse.class))
                    ),
                    @ApiResponse(responseCode = "400", description = "Invalid request data")
            }
    )
    @PostMapping
    public ResponseEntity<QuotationResponse> createQuotation(@Valid @RequestBody QuotationRequest data) {
        QuotationResponse savedQuotation = quotationService.createQuotation(data);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedQuotation);
    }

    @Operation(
            summary = "Get all quotations for a customer",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "List of quotations found",
                            content = @Content(mediaType = "application/json",
                                    array = @ArraySchema(schema = @Schema(implementation = QuotationResponse.class)))
                    ),
                    @ApiResponse(responseCode = "404", description = "Customer not found")
            }
    )
    @GetMapping("/customer/{idCustomer}")
    public ResponseEntity<List<QuotationResponse>> getQuotationsByCustomer(@PathVariable Integer idCustomer) {
        List<QuotationResponse> quotations = quotationService.getQuotationsByCustomer(idCustomer);
        return ResponseEntity.ok(quotations);
    }

    @Operation(
            summary = "Update an existing quotation",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Quotation updated successfully",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = QuotationResponse.class))
                    ),
                    @ApiResponse(responseCode = "404", description = "Quotation or Customer not found")
            }
    )
    @PutMapping("/{idQuotation}")
    public ResponseEntity<QuotationResponse> updateQuotation(
            @PathVariable Integer idQuotation,
            @Valid @RequestBody QuotationRequest data) {

        QuotationResponse updatedQuotation = quotationService.updateQuotation(idQuotation, data);
        return ResponseEntity.ok(updatedQuotation);
    }

    @Operation(
            summary = "Delete a quotation by ID",
            responses = {
                    @ApiResponse(responseCode = "204", description = "Quotation deleted successfully"),
                    @ApiResponse(responseCode = "404", description = "Quotation not found")
            }
    )
    @DeleteMapping("/{idQuotation}")
    public ResponseEntity<Void> deleteQuotation(@PathVariable Integer idQuotation) {
        quotationService.deleteQuotation(idQuotation);
        return ResponseEntity.noContent().build();
    }
}
