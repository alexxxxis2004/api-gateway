package com.example.agency.cars.service;

import com.example.agency.cars.dto.QuotationRequest;
import com.example.agency.cars.dto.QuotationResponse;
import com.example.agency.cars.model.Customer;
import com.example.agency.cars.model.Quotation;
import com.example.agency.cars.repository.CustomerRepository;
import com.example.agency.cars.repository.QuotationRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class QuotationServiceImpl implements QuotationService {

    private final QuotationRepository quotationRepository;
    private final CustomerRepository customerRepository;

    @Override
    public QuotationResponse createQuotation(QuotationRequest data) {
        Customer customer = customerRepository.findById(data.getIdCustomer())
                .orElseThrow(() -> new EntityNotFoundException("Customer not found with id: " + data.getIdCustomer()));

        Quotation quotation = Quotation.builder()
                .customer(customer)
                .date(data.getDate())
                .offeredPrice(data.getOfferedPrice())
                .validity(data.getValidity())
                .build();

        Quotation savedQuotation = quotationRepository.save(quotation);
        return mapToResponse(savedQuotation);
    }

    @Override
    public List<QuotationResponse> getQuotationsByCustomer(Integer idCustomer) {
        Customer customer = customerRepository.findById(idCustomer)
                .orElseThrow(() -> new EntityNotFoundException("Customer not found with id: " + idCustomer));

        List<Quotation> quotations = quotationRepository.findByCustomer(customer);

        return quotations.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public QuotationResponse updateQuotation(Integer idQuotation, QuotationRequest data) {
        Quotation quotation = quotationRepository.findById(idQuotation)
                .orElseThrow(() -> new EntityNotFoundException("Quotation not found with id: " + idQuotation));

        if (data.getIdCustomer() != null) {
            Customer customer = customerRepository.findById(data.getIdCustomer())
                    .orElseThrow(() -> new EntityNotFoundException("Customer not found with id: " + data.getIdCustomer()));
            quotation.setCustomer(customer);
        }

        quotation.setDate(data.getDate());
        quotation.setOfferedPrice(data.getOfferedPrice());
        quotation.setValidity(data.getValidity());

        Quotation updatedQuotation = quotationRepository.save(quotation);
        return mapToResponse(updatedQuotation);
    }

    @Override
    public void deleteQuotation(Integer idQuotation) {
        if (!quotationRepository.existsById(idQuotation)) {
            throw new EntityNotFoundException("Quotation not found with id: " + idQuotation);
        }
        quotationRepository.deleteById(idQuotation);
    }

    private QuotationResponse mapToResponse(Quotation quotation) {
        return QuotationResponse.builder()
                .idQuotation(quotation.getIdQuotation())
                .idCustomer(quotation.getCustomer().getIdCustomer())
                .customerName(quotation.getCustomer().getName())
                .offeredPrice(quotation.getOfferedPrice())
                .validity(quotation.getValidity())
                .date(quotation.getDate())
                .build();
    }
}
