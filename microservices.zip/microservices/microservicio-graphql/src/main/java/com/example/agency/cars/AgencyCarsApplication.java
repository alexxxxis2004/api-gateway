package com.example.agency.cars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgencyCarsApplication {
    public static void main(String[] args) {
        SpringApplication.run(AgencyCarsApplication.class, args);
    }
}
