package com.example.Agency.Cars;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgencyCarsApplicationTests {

	@Test
	void contextLoads() {
	}

}
